"""Local LLM FSM benchmark toolkit."""

__version__ = "1.0.0"
