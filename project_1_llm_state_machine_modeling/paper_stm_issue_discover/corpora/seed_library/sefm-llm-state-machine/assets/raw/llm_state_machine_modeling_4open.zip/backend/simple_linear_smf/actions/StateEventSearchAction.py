from resources.SMFAction import SMFAction
from resources.util import call_llm
from resources.util import extract_states_events_table
import re
from resources.n_shot_examples_simple_linear import get_n_shot_examples

class StateEventSearchAction(SMFAction):
    """
    The StateEventSearchAction is the first step in the Linear SMF. It identifies
    states based on the events that occur in the system

    Input(s): description of system
    Output(s): name of the system, and an HTML table containing columns "Current State", "Event", and "Next State(s)"
    """
    
    name: str = "state_event_search_action"
    args: dict = {} # provided from the LLM
    usage: str = "Identify all states and their associated events that trigger transitions in the system"
    description: str = ""
    log_file_path: str = ""

    def execute(self):
        """
        The execute function prompts the LLM to identify the states/events 
        using a 2-shot prompting approach
        """

        self.log(f"Running {self.name}...")
        n_shot_example_list = self.belief.get("n_shot_examples")

        prompt = f"""
            Given the problem description, identify what the states and events are. 
            Ensure that the states you come up with are coming directly from the provided system description.
            If a system tracks something in provided description, ensure you track it as well through states, no matter how relevant or useful it seems to you.
            Often times, a system will track a minor detail, which you may decide to track only in events. 
            However, if an element is mentioned in an event, it should be represented in states as well, otherwise your response will be rejected.
            Keep in mind that the system can be in multiple states at a time. So try to include as many states as possible.
            It's important to note that states might have multiple events occurring on them resulting in multiple transitions from the current state to other states. 
            A complete state machine often is in multiple states at a time.

            Output the name of the system in the following format:  
            <system_name>System Name</system_name> 
            
            Then produce the HTML table that summarizes the states and events MUST use these table headers:
            ```html <table border="1"> <tr> <th>Current State</th> <th>Event</th> <th>Next State(s)</th> </tr> </table> ```

             {get_n_shot_examples(n_shot_example_list, ["system_description", "transitions_events_table"])}

            It is extremely important to check the problem description for any continuous event that occurs repeatedly, as these events should be represented in separate states. 
            While you may think these events should merely be transitions, we need to capture the fact that these events are occuring repeatedly in the table. 
            In the end, we will take into account parallel regions such that these independent states/events don't interfere with other states.
            If you find any such event, you must include 1 or more rows for each in transitions_events_table. 
            Such events must not interfere with other states at all.
            At the most basic level, this continous event will be a state on it's own, with transitions being from and to the same state.
            At a more advanced level, this would be represented in multiple new states, independent of any other state used for other purposes.
            If there is such event, and the table does not include the appropriate rows, your response will be rejected.
            Don't worry about the system being in 1 state at a time. Assume that the system can be in multiple states at a time.

            It is also extremely important that states do not behave like actions. States should not do things, they should be doing or being things. For example, don't use "Stop at X" as an example, but rather "At X"

            Sometimes you may come across events that are dependent on eachother. 
            For example, let's say you have event X and Y, except that event Y can only take place after event X. 
            In this case, consider making them actual states in addition to keeping the events. 
            They could potentially be treated separately from the the other states, as a parallel region.
            For example, if you have state A with event XY, you can have state A, X, Y, in addition to event XY.

            Don't get too caught up with what the focus of the state machine is. We can focus on multiple aspects of the system in parallel.
            Also, be as granular as you can. If you can think of an event affecting potential states, then include them, even if they seem irrelvant to the focus of the system.
            
            Sometimes you may find a state XY, but the model could reflect the system more accurately if they were to be split into state X and Y. To identify these, consider if state X and Y would have the same transitions. If yes, then keep XY, otherwise split them.
            Keep in mind, sometimes you have a certain state A. And then an event that basically keeps the system in state A for longer. In such cases, do not create a new state A_extended. Keep state A, and add a transition that goes back to itself.
            
            Also avoid "Program End" kind of states. Make sure system is back to it's initial state, unless specified.
            Example:
            
            system_name: 

            system_description: {self.belief.get("description")}

            transitions_events_table:

            Your expertise in identifying system events is critical for defining the precise triggers that drive our state machine's behavior. Each event you recognize shapes how the system reacts to its environment and internal changes. Your systematic analysis of what truly constitutes a meaningful event will create a responsive and well-structured design. Take pride in knowing that your careful event identification lays the foundation for clear and predictable state transitions.
        """

        states_response_in_html = call_llm(prompt, temperature=0.5)

        print(states_response_in_html)

        system_name_search = re.search(r"<system_name>(.*?)</system_name>", states_response_in_html)

        if system_name_search:
            system_name = system_name_search.group(1)
        else:
            system_name = "NOT FOUND"
        self.log(system_name)
        
        # get the states and events table
        state_events_table = extract_states_events_table(states_response_in_html)

        self.log(f"System name: {system_name}")
        self.log(f"State event table: {state_events_table}")
        return (system_name, state_events_table)