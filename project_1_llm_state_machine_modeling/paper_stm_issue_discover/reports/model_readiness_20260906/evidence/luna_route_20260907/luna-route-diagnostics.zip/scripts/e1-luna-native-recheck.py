import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

os.umask(0o077)
sys.path.insert(0, str(Path.cwd()))
from utils.llm import load_llm_registry

cfg = load_llm_registry()['gpt-5.6-luna']
source, = Path('[PRIVATE]
payload = source.read_bytes()
out = Path('[PRIVATE]
out.mkdir(exist_ok=False)
(out/'request.body').write_bytes(payload)
record = {'profile_fingerprint': cfg.fingerprint(), 'source_commit': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'started_at': datetime.now(timezone.utc).isoformat(), 'payload_sha256': hashlib.sha256(payload).hexdigest(),
          'request_matches_failed_adapter_payload': True, 'transport_retries': 0,
          'read_idle_timeout_seconds': 300, 'process_deadline_seconds': 620,
          'http_body_decoded': True, 'formal_result_eligible': False}
start = time.monotonic()
with httpx.Client(timeout=300) as client:
    with client.stream('POST', cfg.base_url.rstrip('/')+'/responses', content=payload,
                      headers={'Authorization': 'Bearer '+cfg.api_key.get_secret_value(), 'Content-Type': 'application/json'}) as response:
        record.update(http_status=response.status_code, headers_seconds=time.monotonic()-start,
                      retry_after=response.headers.get('retry-after'))
        times=[]
        with (out/'response.body').open('wb') as f:
            for chunk in response.iter_bytes():
                times.append(time.monotonic()-start)
                f.write(chunk)
        record.update(seconds=time.monotonic()-start, chunk_times_seconds=times)
(out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['http_status','seconds','retry_after']}))
