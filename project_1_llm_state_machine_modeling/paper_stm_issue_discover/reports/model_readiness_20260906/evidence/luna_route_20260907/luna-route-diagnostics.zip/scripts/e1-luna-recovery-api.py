import asyncio
import json
import os
import runpy
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

os.umask(0o077)
sys.path.insert(0, str(Path.cwd()))
from utils.llm import create_chat_model, load_llm_registry

out = Path('[PRIVATE] / (sys.argv[1] if len(sys.argv) > 1 else 'plain-api')
out.mkdir(parents=True, exist_ok=False)
cfg = load_llm_registry()['gpt-5.6-luna']
os.environ['E1_CALL_AUDIT_DIR'] = str(out)
observer = runpy.run_path('[PRIVATE]
observer['active_calls'].add('plain-generation')
record = {'profile': 'gpt-5.6-luna', 'model': cfg.model, 'adapter': cfg.adapter,
          'profile_fingerprint': cfg.fingerprint(), 'source_commit': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'started_at': datetime.now(timezone.utc).isoformat(), 'formal_result_eligible': False,
          'stream': True, 'prompt': 'Reply with OK.', 'configured_output_cap': cfg.max_output_tokens,
          'run_output_override': None, 'transport_retries': 0, 'thinking_and_sampling': 'provider_default',
          'read_idle_timeout_seconds': 300, 'whole_call_deadline_seconds': 600}
start = time.monotonic()

async def generate():
    model = create_chat_model(cfg, streaming=True, max_retries=0, model_options={'timeout': 300.0})
    merged = None
    chunks = []
    try:
        async for chunk in model.astream([('user', record['prompt'])]):
            chunks.append({'seconds': time.monotonic()-start, 'chunk': chunk.model_dump(mode='json')})
            merged = chunk if merged is None else merged + chunk
        record['response'] = merged.model_dump(mode='json')
        record['chunks'] = chunks
    finally:
        await model.root_async_client.close()
        model.root_client.close()

try:
    asyncio.run(asyncio.wait_for(generate(), timeout=600))
    record['status'] = 'completed'
except Exception as error:
    record.update(status='failed', error_type=type(error).__name__)
finally:
    record['seconds'] = time.monotonic()-start
    (out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record.get(k) for k in ['status','model','seconds','error_type']}))
