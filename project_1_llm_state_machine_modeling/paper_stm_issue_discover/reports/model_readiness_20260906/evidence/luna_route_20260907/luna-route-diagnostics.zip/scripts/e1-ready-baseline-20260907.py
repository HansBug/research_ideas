import hashlib
import json
import os
import runpy
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from subprocess import check_output

os.umask(0o077)
repo = Path.cwd()
sys.path.insert(0, str(repo))
from utils.llm import load_llm_registry
import httpx

profile = sys.argv[1]
variant = sys.argv[2] if len(sys.argv) > 2 else 'baseline'
out = Path('[PRIVATE] / profile / variant
out.mkdir(parents=True, exist_ok=False)
config = load_llm_registry().require(profile)
record = dict(profile=profile, model=config.model, adapter=config.adapter,
              config_fingerprint=config.fingerprint(), context=config.context_window_tokens,
              max_output_tokens=config.max_output_tokens, output_budget_mode=config.output_budget_mode,
              streaming=True, pair='0001', round=1, workers=1, transport_retries=0,
              effort='provider_default; see server template for open models',
              source_commit=check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              formal_result_eligible=False, started_at=datetime.now(timezone.utc).isoformat())
record['variant'] = variant
record['retry_of'] = 'baseline' if variant == 'baseline-provider-retry' else None
if profile.startswith('e1-'):
    response = httpx.get(config.base_url.rstrip('/') + '/models', timeout=30)
    response.raise_for_status()
    record['served_model_ids'] = [row['id'] for row in response.json()['data']]
    assert config.model in record['served_model_ids']

audit_dir = out / 'call_metadata'
os.environ.update(LLM_CONFIG_FILE=str(repo / '.llmconfig.yml'), LANGSMITH_TRACING='false',
                  E1_CALL_AUDIT_DIR=str(audit_dir), E1_OUTPUT_AUDIT_ENABLED='true')
runpy.run_path('[PRIVATE]
original_send = httpx.Client.send

class ObservedStream(httpx.SyncByteStream):
    def __init__(self, original, directory, metadata, start):
        self.original, self.directory, self.metadata, self.start = original, directory, metadata, start

    def __iter__(self):
        times = []
        try:
            with (self.directory / 'response.body').open('wb') as target:
                for chunk in self.original:
                    times.append(time.monotonic() - self.start)
                    target.write(chunk)
                    target.flush()
                    yield chunk
        except BaseException as error:
            self.metadata['error_type'] = type(error).__name__
            raise
        finally:
            self.metadata.update(chunk_times_seconds=times, seconds=time.monotonic()-self.start)
            (self.directory / 'metadata.json').write_text(json.dumps(self.metadata, indent=2)+'\n')

    def close(self):
        self.original.close()

def observed_send(client, request, *args, **kwargs):
    directory = audit_dir / 'wire' / str(time.monotonic_ns())
    directory.mkdir(parents=True)
    payload = request.content
    (directory / 'request.body').write_bytes(payload)
    metadata = dict(sha256=hashlib.sha256(payload).hexdigest(),
                    timeout=request.extensions.get('timeout'), httpx_stream=kwargs.get('stream'))
    start = time.monotonic()
    response = original_send(client, request, *args, **kwargs)
    metadata.update(status_code=response.status_code, headers_seconds=time.monotonic()-start)
    response.stream = ObservedStream(response.stream, directory, metadata, start)
    return response

httpx.Client.send = observed_send
paper = repo / 'project_1_llm_state_machine_modeling/paper_stm_issue_discover'
sys.argv = [str(paper / 'baseline_arm/src/runner.py'), '--report-root',
            str(paper / 'pipeline/representation/reports/llms_emp_r45_java_60'),
            '--output-dir', str(out / 'artifacts'), '--profile', profile, '--case', '0001',
            '--round', '1', '--transport-retries', '0', '--content-language', 'en-US', '--stream']
(out / 'probe.json').write_text(json.dumps(record, indent=2)+'\n')
start = time.monotonic()
with (out / 'process.log').open('w') as log:
    stdout, stderr = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = log
    try:
        runpy.run_path(sys.argv[0], run_name='__main__')
    except SystemExit as exit:
        record['exit_code'] = exit.code
    finally:
        sys.stdout, sys.stderr = stdout, stderr
record.update(seconds=time.monotonic()-start, finished_at=datetime.now(timezone.utc).isoformat())
(out / 'probe.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({key: record.get(key) for key in ['profile', 'exit_code', 'seconds']}))
