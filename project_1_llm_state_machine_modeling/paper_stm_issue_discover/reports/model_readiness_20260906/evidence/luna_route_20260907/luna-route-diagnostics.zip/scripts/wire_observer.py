"""Opt-in HTTP/SSE observation. Request payloads and response bytes pass unchanged."""
import hashlib
import json
import os
import time
import uuid
from pathlib import Path

import httpx
from openai._streaming import SSEDecoder

active_calls = set()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + "\n")


class ObservedStream(httpx.AsyncByteStream):
    def __init__(self, original, directory, record, start):
        self.original = original
        self.directory = directory
        self.record = record
        self.start = start
        self.chunks = []
        self.times = []

    async def __aiter__(self):
        try:
            with (self.directory / "response.body").open("wb") as raw:
                async for chunk in self.original:
                    self.times.append(time.monotonic() - self.start)
                    self.chunks.append(chunk)
                    raw.write(chunk)
                    raw.flush()
                    yield chunk
        except BaseException as error:
            self.record["error_type"] = type(error).__name__
            raise
        finally:
            self.record["body_completed_seconds"] = time.monotonic() - self.start
            self.record["chunk_times_seconds"] = self.times
            self.record["chunk_sizes"] = [len(chunk) for chunk in self.chunks]
            self.record["first_byte_seconds"] = self.times[0] if self.times else None
            self.record["max_chunk_gap_seconds"] = max((b-a for a,b in zip(self.times,self.times[1:])), default=None)
            self.record["first_sse_seconds"] = None
            self.record["first_content_or_tool_seconds"] = None
            events = []
            last_time = None
            def source():
                nonlocal last_time
                for chunk, elapsed in zip(self.chunks, self.times):
                    last_time = elapsed
                    yield chunk
            try:
                for event in SSEDecoder().iter_bytes(source()):
                    if self.record["first_sse_seconds"] is None:
                        self.record["first_sse_seconds"] = last_time
                    entry = {"seconds": last_time, "event": event.event, "done": event.data == "[DONE]"}
                    if not entry["done"]:
                        data = json.loads(event.data)
                        entry["data"] = data
                        choices = data.get("choices", [])
                        meaningful = any((c.get("delta") or {}).get("content") or
                                         any((t.get("function") or {}).get("arguments") for t in (c.get("delta") or {}).get("tool_calls", []))
                                         for c in choices)
                        meaningful |= any((p.get("text") and not p.get("thought")) or p.get("functionCall")
                                          for c in data.get("candidates", []) for p in (c.get("content") or {}).get("parts", []))
                        if data.get("type") == "content_block_delta":
                            delta = data.get("delta") or {}
                            meaningful |= bool(delta.get("text") or delta.get("partial_json"))
                        if meaningful and self.record["first_content_or_tool_seconds"] is None:
                            self.record["first_content_or_tool_seconds"] = last_time
                    events.append(entry)
            except Exception as error:
                self.record["sse_observation_error"] = type(error).__name__
            save(self.directory / "sse-events.json", events)
            save(self.directory / "metadata.json", self.record)

    async def aclose(self):
        await self.original.aclose()


original_send = httpx.AsyncClient.send


async def observed_send(client, request, *args, **kwargs):
    call_id = next(iter(active_calls)) if len(active_calls) == 1 else "unmapped"
    directory = Path(os.environ["E1_CALL_AUDIT_DIR"]) / "wire" / call_id / uuid.uuid4().hex
    directory.mkdir(parents=True, mode=0o700)
    start = time.monotonic()
    payload = request.content
    (directory / "request.body").write_bytes(payload)
    record = {"model_call_id": call_id, "pid": os.getpid(), "started_unix": time.time(),
              "request_sha256": hashlib.sha256(payload).hexdigest(), "request_bytes": len(payload),
              "httpx_stream": kwargs.get("stream", False), "status_code": None,
              "timeout": request.extensions.get("timeout"), "error_type": None}
    save(directory / "metadata.json", record)
    try:
        response = await original_send(client, request, *args, **kwargs)
    except BaseException as error:
        record.update(error_type=type(error).__name__, ended_seconds=time.monotonic() - start)
        save(directory / "metadata.json", record)
        raise
    record.update(status_code=response.status_code, response_headers_seconds=time.monotonic() - start,
                  content_type=response.headers.get("content-type"))
    save(directory / "metadata.json", record)
    if not response.is_stream_consumed:
        response.stream = ObservedStream(response.stream, directory, record, start)
    else:
        (directory / "response.body").write_bytes(response.content)
        record["sse_observation_error"] = "response_consumed_before_observer"
        save(directory / "metadata.json", record)
    return response


httpx.AsyncClient.send = observed_send
