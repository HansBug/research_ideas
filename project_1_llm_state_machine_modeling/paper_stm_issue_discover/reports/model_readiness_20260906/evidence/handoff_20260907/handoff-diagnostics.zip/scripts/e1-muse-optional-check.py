import importlib.util
import json
from pathlib import Path

import xgrammar
from transformers import AutoTokenizer

root=Path('[PRIVATE]
spec=importlib.util.spec_from_file_location('serving_muse',root/'serving_muse.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
request=json.loads((root/'muse-contract-request.json').read_text())
function=request['tools'][0]['function']
schema=function['parameters']
previous=json.loads(request['messages'][2]['tool_calls'][0]['function']['arguments'])
tokenizer=AutoTokenizer.from_pretrained(root/'hf/hub/models--meta-models--Muse-Glimmer-30B/snapshots/a4e59da52a7bc87ae7251dd5545c0dd437c44b68',local_files_only=True)
compiled=xgrammar.GrammarCompiler(xgrammar.TokenizerInfo.from_huggingface(tokenizer)).compile_structural_tag(json.dumps(module.muse_structural_tag(request['tools'],request['tool_choice'])))
def text(value):
    name=function['name']
    parts=[]
    for key in schema['properties']:
        if key not in value:continue
        part=value[key] if isinstance(value[key],str) else json.dumps(value[key],ensure_ascii=False)
        parts.append('<atem:parameter name="'+key+'">'+part+'</atem:parameter>')
    return '<|start|>assistant to='+name+'<|message|><atem:function_calls><atem:invoke name="'+name+'">'+'\n'.join(parts)+'</atem:invoke></atem:function_calls>'
def check(value):
    matcher=xgrammar.GrammarMatcher(compiled)
    return matcher.accept_string(text(value)) and matcher.accept_token(tokenizer.eos_token_id)
before=check(previous)
row=previous['contracts'][2]
row['binding_hints']=[{'role':'source','value':'InitialState','reason':'The transition originates here.','basis':'NL2'},
                      {'role':'target','value':'HighwayMode','reason':'The transition ends here.','basis':'NL2'}]
appended=check(previous)
ordered={key:row[key] for key in schema['properties']['contracts']['items']['properties'] if key in row}
previous['contracts'][2]=ordered
in_schema_order=check(previous)
print(json.dumps({'previous_accepted':before,'optional_appended_after_required':appended,
                  'optional_in_schema_order':in_schema_order,'actual_schema_properties':list(schema['properties']['contracts']['items']['properties'])}))
