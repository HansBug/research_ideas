import gzip
import json
from pathlib import Path

ROOT=Path('[PRIVATE]

def read(path):
    return json.loads(path.read_text())

def events(path):
    data=path.read_bytes()
    if data.startswith(b'\x1f\x8b'):
        data=gzip.decompress(data)
    for line in data.decode().splitlines():
        if line.startswith('data: ') and line[6:]!='[DONE]':
            yield json.loads(line[6:])

rows=[]
for profile in ('gpt-5.6-luna','claude-sonnet-5','e1-qwen38-27b','e1-muse30b'):
    for folder in sorted((ROOT/profile).iterdir()):
        record_path=folder/'artifacts/record.json'
        if not record_path.exists():
            continue
        record=read(record_path)
        row={'profile':profile,'variant':folder.name,'probe':read(folder/'probe.json'),
             'status':record['status'],'failure_class':record['failure_class'],
             'configured_model':record['configured_model'],'observed_model':record['observed_model'],
             'usage':record.get('usage'),'attempts':record['attempts'],'wire':[]}
        for path in sorted((folder/'call_metadata/wire').glob('*/metadata.json')):
            metadata=read(path)
            payload=read(path.parent/'request.body')
            wire={'status':metadata['status_code'],'payload_sha256':metadata['sha256'],
                  'stream':payload['stream'],'output_caps':{key:payload[key] for key in ('max_tokens','max_completion_tokens','max_output_tokens') if key in payload},
                  'reasoning_and_sampling':{key:payload[key] for key in ('thinking','reasoning','reasoning_effort','temperature','top_p','top_k','chat_template_kwargs') if key in payload},
                  'usage':[],'finish_reasons':[],'seconds':metadata['seconds'],
                  'timeout':metadata.get('timeout'),'chunk_times_seconds':metadata['chunk_times_seconds']}
            if wire['status']==200:
                for event in events(path.parent/'response.body'):
                    usage=event.get('usage') or event.get('message',{}).get('usage') or event.get('response',{}).get('usage')
                    if usage:wire['usage'].append(usage)
                    reasons=[c['finish_reason'] for c in event.get('choices',[]) if c.get('finish_reason')]
                    if event.get('delta',{}).get('stop_reason'):reasons.append(event['delta']['stop_reason'])
                    if event.get('type') in ('response.completed','response.incomplete','response.failed'):
                        reasons.append(event['type'])
                        wire['incomplete_details']=event['response'].get('incomplete_details')
                    wire['finish_reasons'].extend(reasons)
            row['wire'].append(wire)
        assert row['wire'] and all(w['stream'] for w in row['wire'])
        if row['status']=='ok':
            assert row['observed_model']==row['configured_model']
            assert row['usage']['status']=='completed'
            assert all(w['status']==200 and w['usage'] and w['finish_reasons'] for w in row['wire'])
        rows.append(row)
(ROOT/'baseline-audit.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'profile':r['profile'],'variant':r['variant'],'status':r['status'],
                  'http':[w['status'] for w in r['wire']],'usage':r['usage'].get('status') if r['usage'] else None} for r in rows]))
