import hashlib
import json
import os
import shlex
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

os.umask(0o077)
sys.path.insert(0, str(Path.cwd()))
from utils.llm import load_llm_registry

root = Path('[PRIVATE]
profiles = {}
registry = load_llm_registry()
for name in ('gpt-5.6-luna', 'claude-sonnet-5', 'e1-qwen38-27b', 'e1-muse30b'):
    config = registry.require(name)
    public = config.model_dump(mode='json', exclude={'base_url', 'api_key', 'pricing'})
    public.update(fingerprint=config.fingerprint(), api_key_present=config.api_key is not None)
    profiles[name] = public
record = {'verified_at': datetime.now(timezone.utc).isoformat(), 'profiles': profiles,
          'registry_profiles': len(registry),
          'config_permissions': oct((Path.cwd()/'.llmconfig.yml').stat().st_mode & 0o777),
          'source_commit': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
(root/'final-profiles.json').write_text(json.dumps(record,indent=2)+'\n')

remote_code = '''import importlib.metadata,json,subprocess,sys
from pathlib import Path
prefix=Path(sys.prefix)
assert (prefix/'conda-meta').is_dir()
print(json.dumps({'python':sys.version.split()[0], 'conda_packages':[
 {k:v for k,v in json.loads(p.read_text()).items() if k in ['name','version','build','channel','url','sha256']}
 for p in sorted((prefix/'conda-meta').glob('*.json'))],
 'pip_packages':json.loads(subprocess.check_output([sys.executable,'-m','pip','list','--format=json'],text=True))}))
'''
for model in ('e1-qwen38-27b', 'e1-muse30b'):
    executable='[PRIVATE]
    response=subprocess.run(['ssh','-o','ControlPath=none','xai',shlex.join([executable,'-'])],
        input=remote_code,text=True,capture_output=True,check=True)
    metadata=json.loads(response.stdout)
    (root/(model+'-environment.json')).write_text(json.dumps(metadata,indent=2)+'\n')
    lock=''.join(p['name']+'=='+p['version']+'\n' for p in sorted(metadata['pip_packages'],key=lambda p:p['name'].lower()))
    (root/(model+'-pip-lock.txt')).write_text(lock)
    print(json.dumps({'model':model,'python':metadata['python'],'packages':len(metadata['pip_packages']),
                      'lock_sha256':hashlib.sha256(lock.encode()).hexdigest()}))
print(json.dumps({'registry_profiles':record['registry_profiles'],'config_permissions':record['config_permissions']}))
