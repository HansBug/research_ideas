import hashlib
import json
import shlex
import subprocess
import sys
from pathlib import Path

root = Path('[PRIVATE]
variant = sys.argv[1] if len(sys.argv)>1 else 'original'
code = '''import hashlib,importlib.metadata as m,json,subprocess
from pathlib import Path
root=Path('[PRIVATE]
processes=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit(): continue
 try:
  command=(p/'cmdline').read_bytes().split(b'\\0')
  if str(root/'serving_muse.py').encode() not in command: continue
  env=dict(item.split(b'=',1) for item in (p/'environ').read_bytes().split(b'\\0') if b'=' in item)
  processes.append({'pid':int(p.name),'command':[part.decode() for part in command if part],
    'environment':{key:env.get(key.encode(),b'').decode() for key in ['CUDA_VISIBLE_DEVICES','CONDA_PREFIX','CUDA_HOME','PYTHONNOUSERSITE','SGLANG_MAX_NEW_TOKENS_LIMIT','SGLANG_ALLOW_AUTO_TRUNCATE','SGLANG_CACHE_DIR','CUDA_CACHE_PATH','XDG_CACHE_HOME','TMPDIR']}})
 except (FileNotFoundError,PermissionError,ProcessLookupError): continue
assert processes
generation=json.loads((root/'hf/hub/models--meta-models--Muse-Glimmer-30B/snapshots/a4e59da52a7bc87ae7251dd5545c0dd437c44b68/generation_config.json').read_text())
print(json.dumps({'processes':processes,'xgrammar':m.version('xgrammar'),'model_generation_config':generation,
 'adapter_sha256':hashlib.sha256((root/'serving_muse.py').read_bytes()).hexdigest(),
 'startup_script_sha256':hashlib.sha256((root/'e1-muse-structural-start.sh').read_bytes()).hexdigest()}))
'''
r=subprocess.run(['ssh','-o','ControlPath=none','xai',shlex.join(['[PRIVATE]
                 input=code,text=True,capture_output=True,check=True)
record=json.loads(r.stdout)
assert record['adapter_sha256']==hashlib.sha256(Path('utils/llm/serving_muse.py').read_bytes()).hexdigest()
assert record['startup_script_sha256']==hashlib.sha256(Path('[PRIVATE]
assert all(p['environment']['CUDA_VISIBLE_DEVICES']=='4,5,6,7' for p in record['processes'])
record['attribution_note']='This actual process/launcher capture supersedes the generic startup_script_sha256 in the companion active-server-snapshot.json, whose helper assumed the unmodified upstream launcher.'
record['source_commit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
record['adapter_commit']=subprocess.check_output(['git','log','-1','--format=%H','--','utils/llm/serving_muse.py'],text=True).strip()
target=root/('muse-serving-identity.json' if variant=='original' else 'muse-serving-identity-'+variant+'.json')
assert not target.exists()
target.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'matching_live_adapter':True,'xgrammar':record['xgrammar'],'gpu_scope':[4,5,6,7]}))
