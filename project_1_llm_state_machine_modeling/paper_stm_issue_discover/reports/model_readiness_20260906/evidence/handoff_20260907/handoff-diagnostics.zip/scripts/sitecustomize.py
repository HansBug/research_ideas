"""Opt-in metadata observer; does not edit messages or provider arguments."""
import os

if os.environ.get("E1_CALL_AUDIT_DIR"):
    import json
    from contextvars import ContextVar
    from datetime import datetime, timezone
    from pathlib import Path

    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.tracers.context import register_configure_hook

    FIELDS = frozenset({
        "model", "model_name", "modelVersion", "model_version", "model_id",
        "max_tokens", "max_output_tokens", "max_completion_tokens", "maxOutputTokens",
        "reasoning_effort", "reasoning", "thinking_level", "thinking_budget",
        "thinking", "thinkingConfig", "effort", "type", "budget_tokens",
        "temperature", "top_p", "top_k", "stream", "streaming", "stream_usage",
        "finish_reason", "finishReason", "stop_reason", "status", "incomplete_details", "reason",
        "token_usage", "usage", "usage_metadata", "usageMetadata",
        "input_tokens", "output_tokens", "total_tokens", "prompt_tokens",
        "completion_tokens", "reasoning_tokens", "cached_tokens",
        "input_token_details", "output_token_details", "prompt_tokens_details",
        "completion_tokens_details", "cache_read", "cache_creation",
        "promptTokenCount", "candidatesTokenCount", "totalTokenCount",
        "thoughtsTokenCount", "cachedContentTokenCount", "chat_template_kwargs",
        "enable_thinking", "reasoning_strength", "extra_body",
    })

    def select(value):
        if isinstance(value, dict):
            return {k: select(v) for k, v in value.items() if k in FIELDS}
        if isinstance(value, (list, tuple)):
            return [select(v) for v in value]
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        return None

    class OutputAudit(BaseCallbackHandler):
        raise_error = False

        def emit(self, event, run_id, **data):
            root = Path(os.environ["E1_CALL_AUDIT_DIR"])
            root.mkdir(mode=0o700, parents=True, exist_ok=True)
            item = {"event": event, "model_call_id": str(run_id), "pid": os.getpid(),
                    "recorded_at": datetime.now(timezone.utc).isoformat(), **data}
            path = root / (str(run_id) + ".jsonl")
            fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
            try:
                os.write(fd, (json.dumps(item, ensure_ascii=True) + "\n").encode())
            finally:
                os.close(fd)

        def on_chat_model_start(self, serialized, messages, *, run_id, **kwargs):
            if os.environ.get("E1_WIRE_AUDIT_ENABLED") == "true":
                wire_observer.active_calls.add(str(run_id))
            self.emit("request", run_id, parameters=select(kwargs.get("invocation_params", {})),
                      metadata=select(kwargs.get("metadata", {})),
                      message_counts=[len(batch) for batch in messages])

        def on_llm_end(self, response, *, run_id, **kwargs):
            generations = []
            for batch in response.generations:
                for generation in batch:
                    message = getattr(generation, "message", None)
                    generations.append({
                        "generation_info": select(getattr(generation, "generation_info", {})),
                        "response_metadata": select(getattr(message, "response_metadata", {})),
                        "usage_metadata": select(getattr(message, "usage_metadata", {})),
                        "tool_call_count": len(getattr(message, "tool_calls", []) or []),
                        "invalid_tool_call_count": len(getattr(message, "invalid_tool_calls", []) or []),
                    })
            self.emit("response", run_id, llm_output=select(response.llm_output or {}),
                      generations=generations)
            if os.environ.get("E1_WIRE_AUDIT_ENABLED") == "true":
                wire_observer.active_calls.discard(str(run_id))

        def on_llm_error(self, error, *, run_id, **kwargs):
            self.emit("error", run_id, error_type=type(error).__name__)
            if os.environ.get("E1_WIRE_AUDIT_ENABLED") == "true":
                wire_observer.active_calls.discard(str(run_id))

    register_configure_hook(ContextVar("e1_output_audit", default=None), True,
                            OutputAudit, "E1_OUTPUT_AUDIT_ENABLED")
    if os.environ.get("E1_WIRE_AUDIT_ENABLED") == "true":
        import wire_observer
