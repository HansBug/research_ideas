import hashlib
import json
import os
import sys
import time
from pathlib import Path

import httpx

sys.path.insert(0, str(Path.cwd()))
from utils.llm import load_llm_registry

os.umask(0o077)
cfg = load_llm_registry()['gpt-5.6-luna']
variant = sys.argv[1] if len(sys.argv) > 1 else 'baseline'
assert variant in {'baseline', 'plain-responses', 'baseline-chat-completions'}
out = Path('[PRIVATE] + ('' if variant == 'baseline' else '-' + variant))
out.mkdir(exist_ok=False)
source = Path('[PRIVATE]
payload = source.read_bytes()
if variant == 'plain-responses':
    payload = json.dumps({'model': cfg.model, 'input': 'Reply with OK.', 'stream': True,
                          'max_output_tokens': cfg.max_output_tokens}).encode()
if variant == 'baseline-chat-completions':
    source_payload = json.loads(payload)
    payload = json.dumps({'model': cfg.model, 'stream': True, 'stream_options': {'include_usage': True},
                          'max_completion_tokens': cfg.max_output_tokens,
                          'messages': [{k: message[k] for k in ('role', 'content')} for message in source_payload['input']],
                          'tools': [{'type': 'function', 'function': {k: v for k, v in tool.items() if k != 'type'}} for tool in source_payload['tools']],
                          'tool_choice': {'type': 'function', 'function': {'name': source_payload['tool_choice']['name']}},
                          'parallel_tool_calls': source_payload['parallel_tool_calls']}).encode()
assert json.loads(payload)['stream'] is True
(out / 'request.body').write_bytes(payload)
headers = {'Authorization': 'Bearer ' + cfg.api_key.get_secret_value(), 'Content-Type': 'application/json'}
record = {'profile_fingerprint': cfg.fingerprint(), 'payload_sha256': hashlib.sha256(payload).hexdigest(),
          'variant': variant, 'boundary': 'Native route diagnosis, never a substitute for baseline acceptance; zero transport retries'}
with httpx.Client(timeout=600) as client:
    inventory = client.get(cfg.base_url.rstrip('/') + '/models', headers=headers)
    record['inventory_status'] = inventory.status_code
    if inventory.is_success:
        record['inventory_has_model'] = cfg.model in [row['id'] for row in inventory.json().get('data', [])]
    start = time.monotonic()
    route = '/chat/completions' if variant == 'baseline-chat-completions' else '/responses'
    with client.stream('POST', cfg.base_url.rstrip('/') + route, headers=headers, content=payload) as response:
        record.update(status=response.status_code, headers_seconds=time.monotonic()-start,
                      retry_after=response.headers.get('retry-after'))
        times = []
        with (out / 'response.body').open('wb') as target:
            for chunk in response.iter_bytes():
                times.append(time.monotonic()-start)
                target.write(chunk)
        record.update(chunk_times_seconds=times, seconds=time.monotonic()-start)
(out / 'result.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({key:record[key] for key in ('inventory_status','status','seconds','retry_after')}))
