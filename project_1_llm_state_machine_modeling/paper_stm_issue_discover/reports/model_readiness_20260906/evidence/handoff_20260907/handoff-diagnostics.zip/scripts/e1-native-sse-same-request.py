"""Send a captured payload unchanged; credentials stay in a private connection file."""
import argparse
import asyncio
import hashlib
import json
import os
import sys
import time
from pathlib import Path

import httpx

parser = argparse.ArgumentParser()
parser.add_argument("--payload", type=Path, required=True)
parser.add_argument("--connection", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--observer", type=Path, required=True)
parser.add_argument("--label", required=True)
args = parser.parse_args()
os.umask(0o077)
args.output.mkdir(parents=True, exist_ok=False)
os.environ["E1_CALL_AUDIT_DIR"] = str(args.output)
sys.path.insert(0, str(args.observer))
import wire_observer
wire_observer.active_calls.add(args.label)
payload = args.payload.read_bytes()
assert json.loads(payload)["stream"] is True
connection = json.loads(args.connection.read_text())
record = {"label": args.label, "request_sha256": hashlib.sha256(payload).hexdigest(),
          "stream": True, "first_byte_read_idle_seconds": 300, "total_deadline_seconds": 600,
          "error_type": None, "http_status": None}
async def run():
    async with httpx.AsyncClient(timeout=httpx.Timeout(300)) as client:
        async with client.stream("POST", connection["base_url"].rstrip("/") + "/chat/completions",
                                 headers={"Authorization": "Bearer " + connection["api_key"],
                                          "Content-Type": "application/json"}, content=payload) as response:
            record["http_status"] = response.status_code
            await response.aread()
            response.raise_for_status()
start = time.monotonic()
try:
    asyncio.run(asyncio.wait_for(run(), timeout=600))
except Exception as error:
    record["error_type"] = type(error).__name__
record["seconds"] = time.monotonic() - start
(args.output / "result.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record))
