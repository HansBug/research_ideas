"""Reuse the existing load client and calibrated E1 protocol after environment migration."""
import json
import os
import subprocess
import sys
from pathlib import Path

import requests

os.umask(0o077)
sys.path.insert(0, str(Path.cwd()))
from utils.llm import load_llm_registry

model, case = sys.argv[1:3]
variant = sys.argv[3] if len(sys.argv) > 3 else "model-max"
assert model in {"qwen38", "muse"}
assert case in {"long16k", "native90", "extended90"}
profile = "e1-qwen38-27b" if model == "qwen38" else "e1-muse30b"
source_name = {
    ("qwen38", "long16k"): "qwen38-yarn-long16k-thinking",
    ("qwen38", "native90"): "qwen38-context90-plus",
    ("qwen38", "extended90"): "qwen38-yarn900k",
    ("muse", "long16k"): "muse-high-tool-long16k",
    ("muse", "native90"): "muse-high-tool-context90",
}[(model, case)]
previous = json.loads((Path("[PRIVATE]") / source_name / "manifest.json").read_text())
if model == "qwen38" and case == "native90":
    previous.update(input_tokens=235930, tokenize_path="/tokenize", timeout=300)
config = load_llm_registry()[profile]
out = Path("[PRIVATE]") / model / variant / case
out.parent.mkdir(parents=True, exist_ok=True)
assert not out.exists()
headers = {"Authorization": "Bearer " + config.api_key.get_secret_value()}
response = requests.get(config.base_url.rstrip("/") + "/models", headers=headers, timeout=20)
response.raise_for_status()
assert config.model in [r["id"] for r in response.json()["data"]]
command = [sys.executable, str(Path.cwd() / "project_1_llm_state_machine_modeling/paper_stm_issue_discover/reports/model_readiness_20260906/load_client.py"),
    "--endpoint", config.base_url, "--model", config.model,
    "--configuration", model + "-isolated-conda-gpu47-" + case,
    "--output", str(out), "--input-tokens", str(previous["input_tokens"]),
    "--output-tokens", str(config.max_output_tokens), "--rounds", "2",
    "--concurrency", "16" if case == "long16k" else "1",
    "--tokenize-path", previous["tokenize_path"], "--timeout", "600"]
for key, flag in [("thinking", "--thinking"), ("tool_call", "--tool-call")]:
    if previous.get(key) or (key == "tool_call" and case == "long16k"):
        command.append(flag)
if config.output_budget_mode == "remaining_context":
    command.append("--remaining-context-output")
for key, flag in [("extra_body", "--extra-body"), ("system_prompt", "--system-prompt")]:
    if previous.get(key):
        command.extend([flag, previous[key]])
record = {"profile": profile, "model": config.model, "profile_fingerprint": config.fingerprint(),
          "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
          "previous_probe": source_name, "physical_gpus": [4, 5, 6, 7],
          "isolated_conda": True, "stream": True, "method_or_judge_calls": 0,
          "configuration_change": "Independent conda; long16k uses function tool with 16 workers. Qwen native-size input is recalibrated to 235930 remote tokens on the final 1M serving configuration; it is not a native-RoPE configuration comparison."}
record.update(request_max_output_tokens=config.max_output_tokens, output_budget_source="verified_model_profile",
              serving_output_constraint="SGLang context minus complete input minus one, also bounded by KV page capacity; input auto-truncation disabled")
if config.output_budget_mode == "remaining_context":
    record.update(request_max_output_tokens=None, declared_max_output_tokens=config.max_output_tokens,
                  output_budget_source="provider_remaining_context")
(out.parent / (case + "-handoff.json")).write_text(json.dumps(record, indent=2) + "\n")
result = subprocess.run(command)
raise SystemExit(result.returncode)
