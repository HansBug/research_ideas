"""Capture the active profile and its isolated serving environment without printing credentials."""
import hashlib
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path

import requests

os.umask(0o077)
sys.path.insert(0, str(Path.cwd()))
from utils.llm import load_llm_registry

model = sys.argv[1]
profile, env_name = {
    "qwen38": ("e1-qwen38-27b", "e1-qwen38-27b"),
    "muse": ("e1-muse30b", "e1-muse30b"),
}[model]
config = load_llm_registry()[profile]
out = Path("[PRIVATE]") / model
if len(sys.argv) > 2:
    out = out / sys.argv[2]
out.mkdir(parents=True, exist_ok=True)
headers = {"Authorization": "Bearer " + config.api_key.get_secret_value()}
responses = {}
for route in ("/v1/models", "/get_server_info"):
    response = requests.get(config.base_url.removesuffix("/v1") + route, headers=headers, timeout=30)
    response.raise_for_status()
    responses[route] = response.json()
assert config.model in [r["id"] for r in responses["/v1/models"]["data"]]
remote_code = '''import importlib.metadata,json,os,shutil,subprocess,sys
from pathlib import Path
names=['sglang','torch','transformers','flashinfer-python','nvidia-cuda-nvcc','nvidia-cuda-runtime']
versions={}
for name in names:
 try: versions[name]=importlib.metadata.version(name)
 except importlib.metadata.PackageNotFoundError: versions[name]=None
print(json.dumps({'versions':versions,'python':sys.version.split()[0],
'independent_conda':(Path(sys.prefix)/'conda-meta').is_dir(),
'physical_gpus':[4,5,6,7],
'gpu_state':subprocess.check_output(['nvidia-smi','-i','4,5,6,7','--query-gpu=index,name,memory.used,utilization.gpu','--format=csv,noheader'],text=True),
'shared_disk_free_bytes':shutil.disk_usage('/nfs').free}))
'''
remote = subprocess.run(["ssh", "xai", shlex.join([
    "[PRIVATE]" + env_name + "/bin/python", "-"])],
    input=remote_code, text=True, capture_output=True, check=True)
record = {"profile": profile, "model": config.model, "profile_fingerprint": config.fingerprint(),
          "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
          "context_window_tokens": config.context_window_tokens,
          "profile_max_output_tokens": config.max_output_tokens,
          "server": responses, "environment": json.loads(remote.stdout),
          "startup_script_sha256": hashlib.sha256(Path(sys.argv[3] if len(sys.argv) > 3 else "[PRIVATE]").read_bytes()).hexdigest()}
(out / "active-server-snapshot.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"model": config.model, "identity_matches": True, "environment": record["environment"]}))
