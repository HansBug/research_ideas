#!/usr/bin/env bash
set -euo pipefail
E1_ROOT=${E1_SHARED_ROOT:?}
E1_PREFIX="$E1_ROOT/conda-envs/e1-muse30b"
E1_SNAPSHOT="$E1_ROOT/hf/hub/models--meta-models--Muse-Glimmer-30B/snapshots/a4e59da52a7bc87ae7251dd5545c0dd437c44b68"
test -d "$E1_PREFIX/conda-meta"
test -f "$E1_SNAPSHOT/config.json"
test -z "$(nvidia-smi -i 4,5,6,7 --query-compute-apps=pid --format=csv,noheader,nounits)" || exit 3
export CUDA_VISIBLE_DEVICES=4,5,6,7 CONDA_PREFIX="$E1_PREFIX" PYTHONNOUSERSITE=1
unset PYTHONPATH CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH LIBRARY_PATH CUDA_PATH
export CUDA_HOME="$E1_PREFIX/lib/python3.12/site-packages/nvidia/cu13"
export PATH="$E1_PREFIX/bin:$CUDA_HOME/bin:/usr/bin:/bin"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$CUDA_HOME/lib:$E1_PREFIX/lib"
export HF_HOME="$E1_ROOT/hf" HF_HUB_OFFLINE=1
export XDG_CACHE_HOME="$E1_ROOT/cache" TMPDIR="$E1_ROOT/tmp"
export SGLANG_CACHE_DIR="$E1_ROOT/cache/muse-sglang"
export CUDA_CACHE_PATH="$E1_ROOT/cache/muse-cuda"
cd "$E1_ROOT"
exec "$E1_PREFIX/bin/python" "$E1_ROOT/serving_muse.py" \
  --model-path "$E1_SNAPSHOT" --host [PRIVATE] --port 8100 --tp-size 4 \
  --mem-fraction-static 0.92 --max-running-requests 64 --served-model-name muse-glimmer-30b \
  --context-length 131072 --reasoning-parser muse --tool-call-parser muse
