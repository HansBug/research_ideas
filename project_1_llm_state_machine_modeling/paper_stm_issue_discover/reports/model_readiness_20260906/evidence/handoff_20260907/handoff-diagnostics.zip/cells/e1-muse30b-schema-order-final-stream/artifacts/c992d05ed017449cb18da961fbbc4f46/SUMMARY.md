# Evidence-Discovery Run Audit

- run id: `c992d05ed017449cb18da961fbbc4f46`
- run contract: `sha256:fc6c02e0083136c802d94ed91e202c317fcf2ace8a9ba93941aa28b3481a98d7`
- status: `completed`
- scope: `diagnostic_subset`
- profile: `e1-muse30b`
- source commit: `c3f01f17a7f836bab3a0946400e06a2d48c704a8`
- source branch: `paper1/e1-model-survey-infrastructure`
- registry: `four-family-12-core.v1`
- pair count: `3`
- method cells: `3`
- method cost USD: `0.0`

## Method Metrics

- method_cells: `3`
- eligible_method_cells: `3`
- method_cell_eligible_rate: `1.0`
- release_issue_count: `24`
- eligible_release_issue_count: `24`
- evidence_record_count: `62`
- witness_levels: `{'W1': 50, 'W2': 12}`
- d_levels: `{'D2': 45, 'D0': 17}`
- unresolved_or_error_records: `0`
- method_diagnostics: `0`
- predicate_execution_receipts: `67`
- executed_predicates: `['G1', 'G3', 'S2', 'S3', 'S5']`
- execution_verdicts: `{'unsupported': 50, 'violation': 12, 'pass': 5}`
- coverage_accounting: `{'predicate_execution_coverage': {'executed_distinct_predicates': 5, 'registry_predicate_denominator': 12, 'executed_predicates': ['G1', 'G3', 'S2', 'S3', 'S5'], 'basis': 'terminal PredicateExecutionReceipt records only; prompt appearance and plans do not count'}, 'w2_finding_coverage': {'w2_evidence_record_count': 12, 'w2_finding_record_count': 12, 'basis': 'method-owned evidence records and deterministic witness level'}, 'full_w2_ledger_coverage': {'status': 'pending_external_judge_mapping', 'reason': 'The method does not read ledger expectations; FULL/W2 ledger coverage is computed only after frozen external Judge expected mapping.', 'basis': 'method/evaluation physical isolation boundary'}}`

## Pair Status

| pair | method cells | eligible | errors | method USD |
|---|---:|---:|---:|---:|
| 0019 | 1 | 1 | 0 | 0.0 |
| 0029 | 1 | 1 | 0 | 0.0 |
| 0049 | 1 | 1 | 0 | 0.0 |
