# Evidence-Discovery Run Audit

- run id: `c81cf6c526b24785816ac29313774b56`
- run contract: `sha256:9b6be045089668b1fa0e4b5127a1e9db43918e29713669fe74f77dd09d3905e6`
- status: `completed_with_diagnostics`
- scope: `diagnostic_subset`
- profile: `e1-muse30b`
- source commit: `496f28beeee8b480197cfa634665a74c6ec1c573`
- source branch: `paper1/e1-model-survey-infrastructure`
- registry: `four-family-12-core.v1`
- pair count: `3`
- method cells: `3`
- method cost USD: `0.0`

## Method Metrics

- method_cells: `3`
- eligible_method_cells: `2`
- method_cell_eligible_rate: `0.6666666666666666`
- release_issue_count: `30`
- eligible_release_issue_count: `25`
- evidence_record_count: `74`
- witness_levels: `{'W1': 51, 'W2': 9, 'W0': 14}`
- d_levels: `{'D2': 58, 'D0': 2, 'D_UNRESOLVED': 14}`
- unresolved_or_error_records: `14`
- method_diagnostics: `1`
- predicate_execution_receipts: `78`
- executed_predicates: `['G1', 'G3', 'S2', 'S3', 'S5']`
- execution_verdicts: `{'unsupported': 65, 'violation': 9, 'pass': 4}`
- coverage_accounting: `{'predicate_execution_coverage': {'executed_distinct_predicates': 5, 'registry_predicate_denominator': 12, 'executed_predicates': ['G1', 'G3', 'S2', 'S3', 'S5'], 'basis': 'terminal PredicateExecutionReceipt records only; prompt appearance and plans do not count'}, 'w2_finding_coverage': {'w2_evidence_record_count': 9, 'w2_finding_record_count': 9, 'basis': 'method-owned evidence records and deterministic witness level'}, 'full_w2_ledger_coverage': {'status': 'pending_external_judge_mapping', 'reason': 'The method does not read ledger expectations; FULL/W2 ledger coverage is computed only after frozen external Judge expected mapping.', 'basis': 'method/evaluation physical isolation boundary'}}`

## Pair Status

| pair | method cells | eligible | errors | method USD |
|---|---:|---:|---:|---:|
| 0019 | 1 | 1 | 0 | 0.0 |
| 0029 | 1 | 1 | 0 | 0.0 |
| 0049 | 1 | 0 | 1 | 0.0 |
