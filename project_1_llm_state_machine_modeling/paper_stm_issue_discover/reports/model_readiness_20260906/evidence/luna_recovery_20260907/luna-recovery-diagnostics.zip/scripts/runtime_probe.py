import json
import os
import runpy
import subprocess
import sys
import time
from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, ConfigDict

os.umask(0o077)
sys.path.insert(0, str(Path.cwd()))
from utils.structured_runtime import PublicStructuredRuntime

class PumpIssue(BaseModel):
    model_config = ConfigDict(extra='forbid')
    issue: str
    source_transition: str
    missing_guard: str
    counterexample: list[str]

out = Path(__file__).parent / 'runtime-tool'
out.mkdir(exist_ok=False)
os.environ.update(E1_CALL_AUDIT_DIR=str(out), LANGSMITH_TRACING='false')
observer = runpy.run_path('[PRIVATE]
observer['active_calls'].add('runtime-tool')
runtime = PublicStructuredRuntime('gpt-5.6-luna', out/'runtime', transport_retries=0, streaming=True)
record = {'profile_fingerprint': runtime.config.fingerprint(), 'source_commit': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'started_at': datetime.now(timezone.utc).isoformat(), 'formal_result_eligible': False,
          'stream': True, 'configured_output_cap': runtime.config.max_output_tokens,
          'run_output_override': None, 'transport_retries': 0, 'method_cells': 0, 'judge_cells': 0}
start=time.monotonic()
try:
    with (out/'process.log').open('w') as log, redirect_stdout(log), redirect_stderr(log):
        outcome=runtime.call(kind='adapter-smoke', schema=PumpIssue,
            system_prompt='Identify only concrete requirement violations.',
            prompt='Requirements: a pump may start only when the safety interlock is closed. It must stop when an emergency event occurs. Source transitions: Idle --> Running : start; Running --> Idle : emergency. Identify the concrete issue and a counterexample. Do not invent extra requirements.',
            artifact_id='runtime-tool', retry_cell_on_provider_error=False)
    record.update(status=outcome.status, typed_response=isinstance(outcome.response,PumpIssue),
                  outcome=outcome.to_dict())
finally:
    runtime.close()
    record.update(seconds=time.monotonic()-start, runtime_closed=not runtime._event_loop_thread.is_alive())
    (out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record.get(k) for k in ['status','typed_response','seconds','runtime_closed']}))
