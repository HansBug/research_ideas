"""Recompute readiness facts from immutable method receipts and transport observations."""
import argparse
import collections
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def lines(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def error_detail(row):
    error = row.get("error")
    if isinstance(error, dict):
        return {"stage": row.get("stage"), "code": error.get("code"),
                "provider_status": (error.get("details") or {}).get("status_code")}
    return {"stage": row.get("stage"), "code": row.get("code"), "detail": error}


def summarize(root):
    runs = sorted((root / "artifacts").glob("*/summary.json"))
    assert len(runs) == 1, "expect exactly one completed run"
    run = runs[0].parent
    summary = read(runs[0])
    result = {"probe": read(root / "probe.json"), "run_id": run.name,
              "overall_status": summary["status"], "pairs": {}, "calls": []}
    contexts = {}
    for audit in (run / "llm/method").rglob("audit.jsonl"):
        relative = audit.relative_to(run / "llm/method")
        for row in lines(audit):
            if row.get("model_call_id"):
                contexts[row["model_call_id"]] = {"pair": relative.parts[0],
                    "stage_path": "/".join(relative.parts[2:-1])}
    for pair, status in sorted(summary["per_pair"].items()):
        cell = read(run / "method" / pair / "round-1.json")
        result["pairs"][pair] = {
            "status": status["status"], "eligible": cell["eligible"],
            "errors": status["errors"], "audit_errors": status["audit_errors"],
            "eligibility_reasons": cell["eligibility_reasons"],
            "error_details": [error_detail(r) for r in cell["errors"]],
            "stage_receipts": [{"name": r["stage_name"], "status": r["status"],
                                "diagnostics": len(r.get("diagnostics") or []),
                                "context_budget": r.get("context_budget")}
                               for r in cell["stage_receipts"]],
            "llm_stages": [{"kind": r["kind"], "status": r["status"],
                            "schema_failures": len(r.get("schema_validation_failures") or []),
                            "attempts": r.get("attempts"), "context_budget": r.get("context_budget")}
                           for r in cell["llm_calls"]],
            "predicate_receipts": len(cell.get("predicate_execution_receipts") or []),
        }
    for callback in sorted((root / "call_metadata").glob("*.jsonl")):
        events = lines(callback)
        responses = [r for r in events if r["event"] == "response"]
        errors = [r.get("error_type") for r in events if r["event"] == "error"]
        generations = [g for r in responses for g in r.get("generations", [])]
        usage = (generations[-1].get("usage_metadata") or {}) if generations else {}
        call = {"model_call_id": callback.stem, **contexts.get(callback.stem, {}),
                "response_events": len(responses), "error_types": errors,
                "normalized_usage": usage,
                "tool_call_count": sum(g.get("tool_call_count", 0) for g in generations),
                "finish_reasons": list(dict.fromkeys(
                    (g.get("response_metadata") or {}).get("finish_reason") or
                    (g.get("response_metadata") or {}).get("stop_reason") or
                    (g.get("generation_info") or {}).get("stop_reason") or
                    (g.get("generation_info") or {}).get("finish_reason") for g in generations)),
                "wire": []}
        for metadata in sorted((root / "call_metadata/wire" / callback.stem).glob("*/metadata.json")):
            wire = read(metadata)
            decoded = metadata.parent / "decoded-wire-observation.json"
            if decoded.exists():
                wire.update(read(decoded))
            request = read(metadata.parent / "request.body")
            wire["configured_request_output_caps"] = {k: request[k] for k in
                ("max_tokens", "max_completion_tokens", "max_output_tokens") if k in request}
            generation_config = request.get("generationConfig", {})
            if "maxOutputTokens" in generation_config:
                wire["configured_request_output_caps"]["maxOutputTokens"] = generation_config["maxOutputTokens"]
            wire["requested_thinking"] = generation_config.get("thinkingConfig", request.get("reasoning", request.get("reasoning_effort")))
            sse = metadata.parent / "sse-events.json"
            if decoded.exists():
                sse = metadata.parent / "decoded-sse-events.json"
            if sse.exists():
                event_data = [e.get("data", {}) for e in read(sse)]
            else:
                event_data = [json.loads(line[6:]) for line in (metadata.parent / "response.body").read_bytes().splitlines()
                              if line.startswith(b"data: ") and line[6:] != b"[DONE]"]
            terminal_responses = [e["response"] for e in event_data if e.get("type") == "response.completed"]
            wire["raw_usage_events"] = [e.get("usageMetadata", e.get("usage"))
                                        for e in event_data if e.get("usageMetadata") or e.get("usage")]
            wire["raw_usage_events"].extend(e["message"]["usage"] for e in event_data
                if isinstance(e.get("message"), dict) and e["message"].get("usage"))
            wire["raw_usage_events"].extend(e["usage"] for e in terminal_responses)
            wire["provider_finish_reasons"] = list(dict.fromkeys(
                c.get("finishReason", c.get("finish_reason"))
                for e in event_data for c in e.get("candidates", e.get("choices", []))
                if c.get("finishReason") or c.get("finish_reason")))
            wire["provider_finish_reasons"].extend(e["delta"]["stop_reason"] for e in event_data
                if isinstance(e.get("delta"), dict) and e["delta"].get("stop_reason"))
            wire["provider_finish_reasons"].extend("response.completed" for e in terminal_responses)
            wire["provider_incomplete_details"] = [e["incomplete_details"] for e in event_data if e.get("incomplete_details")]
            wire["provider_incomplete_details"].extend(e.get("incomplete_details") for e in terminal_responses)
            wire["sse_events"] = len(event_data)
            call["wire"].append(wire)
        result["calls"].append(call)
    calls = result["calls"]
    result["counts"] = {"calls": len(calls), "responses": sum(bool(c["response_events"]) for c in calls),
        "errors": dict(collections.Counter(e for c in calls for e in c["error_types"])),
        "finish_reasons": dict(collections.Counter(f for c in calls for f in c["finish_reasons"] if f)),
        "http_statuses": dict(collections.Counter(str(w["status_code"]) for c in calls for w in c["wire"])),
        "wire_requests": sum(len(c["wire"]) for c in calls),
        "unmapped_wire_requests": len(list((root / "call_metadata/wire/unmapped").glob("*/metadata.json"))),
        "missing_usage": sum(not c["normalized_usage"] for c in calls),
        "max_input_tokens": max((c["normalized_usage"].get("input_tokens", 0) for c in calls), default=0),
        "max_output_tokens": max((c["normalized_usage"].get("output_tokens", 0) for c in calls), default=0),
        "max_first_sse_seconds": max((w.get("first_sse_seconds") or 0 for c in calls for w in c["wire"]), default=0)}
    result["counts"]["compact_count"] = sum(read(p).get("compact_count", 0) or 0
        for p in (run / "llm/method").rglob("result.json"))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = summarize(args.root)
    args.output.write_text(json.dumps(result, ensure_ascii=True, indent=2) + "\n")
    print(json.dumps({"run_id": result["run_id"], "counts": result["counts"],
                      "pairs": {p: {k: r[k] for k in ("status", "eligible", "errors", "audit_errors")}
                                for p, r in result["pairs"].items()}}))
