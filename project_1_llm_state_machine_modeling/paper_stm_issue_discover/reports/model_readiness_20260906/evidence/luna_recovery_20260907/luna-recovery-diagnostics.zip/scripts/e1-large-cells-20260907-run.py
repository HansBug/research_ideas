import json
import hashlib
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import requests

os.umask(0o077)
repo = Path.cwd()
sys.path.insert(0, str(repo))
from utils.llm import load_llm_registry
from utils.structured_runtime import PROVIDER_FIRST_BYTE_TIMEOUT_SECONDS, PROVIDER_CALL_DEADLINE_SECONDS, _structured_stage_deadline_seconds

profile = sys.argv[1]
variant = sys.argv[2] if len(sys.argv) > 2 else "stream-300s"
pairs = sys.argv[3:] or ["0029", "0019", "0049"]
assert all(pair in {"0001", "0029", "0019", "0049"} for pair in pairs)
workers = min(3, len(pairs))
streaming = True
out = Path("[PRIVATE]") / (profile if variant == "baseline" else profile + "-" + variant)
out.mkdir(parents=True, exist_ok=False)
config = load_llm_registry()[profile]
paper = repo / "project_1_llm_state_machine_modeling/paper_stm_issue_discover"
command = [sys.executable, "-m", "paper_stm_method.cli", "--report-root",
           str(paper / "pipeline/representation/reports/llms_emp_r45_java_60"),
           "--output-dir", str(out / "artifacts"), "--profile", profile,
           "--rounds", "1", "--workers", str(workers), "--transport-retries", "0", "--allow-live"]
for pair in pairs:
    command.extend(["--pair-id", pair])
record = {"profile": profile, "model": config.model, "adapter": config.adapter,
          "config_fingerprint": config.fingerprint(), "context_window_tokens": config.context_window_tokens,
          "profile_max_output_tokens": config.max_output_tokens, "method_max_output_tokens": config.max_output_tokens,
          "output_budget_source": "verified_model_profile", "run_output_override": None,
          "output_budget_mode": config.output_budget_mode,
          "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
          "pairs": pairs, "rounds": 1, "workers": workers,
          "streaming": streaming, "transport_retries": 0, "candidate_judge_calls": 0,
          "formal_result_eligible": False, "started_at": datetime.now(timezone.utc).isoformat()}
record["variant"] = variant
record["timeouts"] = {"first_byte_and_read_idle": PROVIDER_FIRST_BYTE_TIMEOUT_SECONDS,
                      "provider_call_total": PROVIDER_CALL_DEADLINE_SECONDS,
                      "stage": _structured_stage_deadline_seconds(0)}
record["observer_sha256"] = hashlib.sha256(Path("[PRIVATE]").read_bytes()).hexdigest()
record["observer_boundary"] = "LangChain configure hook observes metadata only; no request or method mutation"
record["wire_observer_sha256"] = hashlib.sha256(Path("[PRIVATE]").read_bytes()).hexdigest()
if urlsplit(config.base_url or "").hostname in {"localhost", "[PRIVATE]", "::1"}:
    response = requests.get(config.base_url.rstrip("/") + "/models",
                            headers={"Authorization": "Bearer " + config.api_key.get_secret_value()}, timeout=20)
    response.raise_for_status()
    served = [row["id"] for row in response.json()["data"]]
    assert config.model in served, "served model identity does not match selected profile"
    record["observed_model_inventory"] = served
(out / "probe.json").write_text(json.dumps(record, indent=2) + "\n")
env = dict(os.environ, LLM_CONFIG_FILE=str(repo / ".llmconfig.yml"),
           LANGSMITH_TRACING="false", E1_OUTPUT_AUDIT_ENABLED="true",
           E1_WIRE_AUDIT_ENABLED="true",
           E1_CALL_AUDIT_DIR=str(out / "call_metadata"),
           PYTHONPATH=os.pathsep.join(["[PRIVATE]", str(repo), str(paper / "method/src")]))
start = time.monotonic()
print(json.dumps({k: record[k] for k in ("profile", "model", "source_commit", "pairs", "streaming")}), flush=True)
with (out / "process.log").open("w") as log:
    result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode, seconds=time.monotonic() - start,
              finished_at=datetime.now(timezone.utc).isoformat())
(out / "probe.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({k: record[k] for k in ("profile", "exit_code", "seconds")}), flush=True)
