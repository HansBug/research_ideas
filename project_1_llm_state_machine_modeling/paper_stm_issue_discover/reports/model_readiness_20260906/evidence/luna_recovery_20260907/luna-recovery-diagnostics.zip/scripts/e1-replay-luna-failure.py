import asyncio
import hashlib
import json
import sys
from pathlib import Path

import httpx
from openai import APIError

sys.path.insert(0, str(Path.cwd()))
from utils.llm import LLMConfig, create_chat_model

root = Path('[PRIVATE]
wire, = (root/'call_metadata/wire/01a079c2-56a8-7f63-aa1d-2270344221ed').glob('*/request.body')
payload = json.loads(wire.read_text())
raw = (wire.parent/'response.body').read_bytes()
calls = []

def respond(request):
    assert json.loads(request.content) == payload
    calls.append(hashlib.sha256(request.content).hexdigest())
    return httpx.Response(200, headers={'content-type': 'text/event-stream'}, content=raw)

async def run():
    http = httpx.AsyncClient(transport=httpx.MockTransport(respond))
    model = create_chat_model(LLMConfig(adapter='openai-responses', model='gpt-5.6-luna', api_key='offline-key',
                             base_url='[PRIVATE] max_output_tokens=128000),
                             model_options={'http_async_client': http})
    record = {'network_calls': 0, 'source_request_sha256': hashlib.sha256(wire.read_bytes()).hexdigest(),
              'source_response_sha256': hashlib.sha256(raw).hexdigest(), 'same_business_payload': True}
    try:
        stream = await model.root_async_client.responses.create(**payload)
        async with stream:
            async for event in stream:
                pass
        raise AssertionError('failed event was ignored')
    except APIError as error:
        assert error.code == 'server_error' and error.body['status_code'] == 200
        assert len(calls) == 1
        record.update(status='provider_failure_caught', code=error.code, http_status=200,
                      sdk_calls=1, response_closed=stream.response.is_closed)
    finally:
        await model.root_async_client.close()
        model.root_client.close()
    out=Path('[PRIVATE]
    out.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record))

asyncio.run(run())
