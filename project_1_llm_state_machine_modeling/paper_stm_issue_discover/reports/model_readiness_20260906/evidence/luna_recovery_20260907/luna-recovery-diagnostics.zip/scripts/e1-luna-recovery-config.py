import json
import os
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import yaml

os.umask(0o077)
sys.path.insert(0, str(Path.cwd()))
from utils.llm import load_llm_registry

root = Path.cwd()
target = Path('[PRIVATE]
target.mkdir(exist_ok=True)
before = yaml.safe_load(Path('[PRIVATE]
after = yaml.safe_load((root / '.llmconfig.yml').read_text())
assert before.keys() == after.keys()
assert all(before[k] == after[k] for k in before if k != 'profiles')
assert before['profiles'].keys() == after['profiles'].keys()
name = 'gpt-5.6-luna'
changed = sorted(k for k in before['profiles'][name].keys() | after['profiles'][name].keys()
                 if before['profiles'][name].get(k) != after['profiles'][name].get(k))
assert changed == ['api_key', 'base_url']
others = {k: before['profiles'][k] == after['profiles'][k] for k in before['profiles'] if k != name}
assert len(others) == 22 and all(others.values())
registry = load_llm_registry()
profiles = {}
with zipfile.ZipFile(root / 'project_1_llm_state_machine_modeling/paper_stm_issue_discover/reports/model_readiness_20260906/evidence/handoff_20260907/handoff-diagnostics.zip') as z:
    old = json.loads(z.read('ready/final-profiles.json'))['profiles']
for key in ('gpt-5.6-luna', 'claude-sonnet-5', 'e1-qwen38-27b', 'e1-muse30b'):
    cfg = registry[key]
    item = cfg.model_dump(mode='json', exclude={'base_url', 'api_key', 'pricing'})
    item.update(fingerprint=cfg.fingerprint(), api_key_present=cfg.api_key is not None)
    profiles[key] = item
    if key != name:
        assert item == old[key], key
assert profiles[name]['max_output_tokens'] == 128000
assert profiles[name]['context_window_tokens'] == 1050000
assert profiles[name]['adapter'] == 'openai-responses'
assert profiles[name]['model'] == name
record = {'verified_at': datetime.now(timezone.utc).isoformat(), 'source_commit': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'route_id': 'luna-user-route-20260907', 'profiles': profiles,
          'registry_profiles': len(registry), 'config_permissions': oct((root/'.llmconfig.yml').stat().st_mode & 0o777),
          'changed_luna_fields': changed, 'other_profile_equalities': others,
          'other_selected_profiles_match_handoff': True,
          'identity_scope': 'Requested and gateway-reported model ID only; no independently authenticated immutable upstream revision.',
          'private_config_and_backups_excluded': True}
with (target/'config-comparison.json').open('x') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({'changed_luna_fields': changed, 'other_profiles_unchanged': len(others),
                  'selected_profiles_match_prior': True, 'config_permissions': record['config_permissions']}))
