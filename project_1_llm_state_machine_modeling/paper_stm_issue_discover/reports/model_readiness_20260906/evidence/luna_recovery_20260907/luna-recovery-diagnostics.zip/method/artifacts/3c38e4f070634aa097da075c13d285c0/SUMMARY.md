# Evidence-Discovery Run Audit

- run id: `3c38e4f070634aa097da075c13d285c0`
- run contract: `sha256:8c0bf424e381f6d39da6df11addd0b3428ee33c1b20b56535419ffdd2222d47a`
- status: `completed`
- scope: `diagnostic_subset`
- profile: `gpt-5.6-luna`
- source commit: `5cbf1442d6df8bbd3a87ce8d05cc789b5d6a9022`
- source branch: `paper1/e1-model-survey-infrastructure`
- registry: `four-family-12-core.v1`
- pair count: `1`
- method cells: `1`
- method cost USD: `0.03862840000000001`

## Method Metrics

- method_cells: `1`
- eligible_method_cells: `1`
- method_cell_eligible_rate: `1.0`
- release_issue_count: `3`
- eligible_release_issue_count: `3`
- evidence_record_count: `4`
- witness_levels: `{'W2': 4}`
- d_levels: `{'D2': 4}`
- unresolved_or_error_records: `0`
- method_diagnostics: `0`
- predicate_execution_receipts: `5`
- executed_predicates: `['S1', 'S2', 'V1']`
- execution_verdicts: `{'violation': 4, 'pass': 1}`
- coverage_accounting: `{'predicate_execution_coverage': {'executed_distinct_predicates': 3, 'registry_predicate_denominator': 12, 'executed_predicates': ['S1', 'S2', 'V1'], 'basis': 'terminal PredicateExecutionReceipt records only; prompt appearance and plans do not count'}, 'w2_finding_coverage': {'w2_evidence_record_count': 4, 'w2_finding_record_count': 4, 'basis': 'method-owned evidence records and deterministic witness level'}, 'full_w2_ledger_coverage': {'status': 'pending_external_judge_mapping', 'reason': 'The method does not read ledger expectations; FULL/W2 ledger coverage is computed only after frozen external Judge expected mapping.', 'basis': 'method/evaluation physical isolation boundary'}}`

## Pair Status

| pair | method cells | eligible | errors | method USD |
|---|---:|---:|---:|---:|
| 0001 | 1 | 1 | 0 | 0.03862840000000001 |
