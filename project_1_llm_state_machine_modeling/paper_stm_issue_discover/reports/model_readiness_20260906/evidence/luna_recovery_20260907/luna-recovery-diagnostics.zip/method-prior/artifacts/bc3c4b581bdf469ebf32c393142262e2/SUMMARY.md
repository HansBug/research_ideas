# Evidence-Discovery Run Audit

- run id: `bc3c4b581bdf469ebf32c393142262e2`
- run contract: `sha256:d6f220d4b9041b5a8c634aad010688489aaa3093091040cde0ef3817df37c5d9`
- status: `completed`
- scope: `diagnostic_subset`
- profile: `gpt-5.6-luna`
- source commit: `672069f854102d3a2b1b1d07cff9c278eba933a1`
- source branch: `paper1/e1-model-survey-infrastructure`
- registry: `four-family-12-core.v1`
- pair count: `1`
- method cells: `1`
- method cost USD: `0.0`

## Method Metrics

- method_cells: `1`
- eligible_method_cells: `1`
- method_cell_eligible_rate: `1.0`
- release_issue_count: `2`
- eligible_release_issue_count: `2`
- evidence_record_count: `3`
- witness_levels: `{'W0': 1, 'W2': 2}`
- d_levels: `{'D_UNRESOLVED': 1, 'D2': 2}`
- unresolved_or_error_records: `1`
- method_diagnostics: `0`
- predicate_execution_receipts: `4`
- executed_predicates: `['S1', 'V1']`
- execution_verdicts: `{'unsupported': 1, 'violation': 2, 'pass': 1}`
- coverage_accounting: `{'predicate_execution_coverage': {'executed_distinct_predicates': 2, 'registry_predicate_denominator': 12, 'executed_predicates': ['S1', 'V1'], 'basis': 'terminal PredicateExecutionReceipt records only; prompt appearance and plans do not count'}, 'w2_finding_coverage': {'w2_evidence_record_count': 2, 'w2_finding_record_count': 2, 'basis': 'method-owned evidence records and deterministic witness level'}, 'full_w2_ledger_coverage': {'status': 'pending_external_judge_mapping', 'reason': 'The method does not read ledger expectations; FULL/W2 ledger coverage is computed only after frozen external Judge expected mapping.', 'basis': 'method/evaluation physical isolation boundary'}}`

## Pair Status

| pair | method cells | eligible | errors | method USD |
|---|---:|---:|---:|---:|
| 0001 | 1 | 1 | 0 | 0.0 |
